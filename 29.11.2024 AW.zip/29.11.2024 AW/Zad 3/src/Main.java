public class Main {
    public static void main(String[] args) {
        Engine engine1 = new Engine(200);
        Car car1 = new Car(120, engine1);

        Car car2 = car1.clone();
        car1.setSpeed(150);
        car1.getEngine().setHorsepower(250);

        System.out.println("car1: " + car1);
        System.out.println("car2: " + car2);
    }
}
