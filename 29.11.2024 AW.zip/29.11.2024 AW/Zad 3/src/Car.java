public class Car implements Cloneable {
    private int speed;
    private Engine engine;

    public Car(int speed, Engine engine) {
        this.speed = speed;
        this.engine = engine;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public Engine getEngine() {
        return engine;
    }

    @Override
    public Car clone() {
        return new Car(this.speed, this.engine.clone());
    }

    @Override
    public String toString() {
        return "Car{speed=" + speed + ", engine=" + engine.getHorsepower() + "}";
    }
}
