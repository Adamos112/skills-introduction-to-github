import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Produkt[] produkty = {
                new Produkt("Mleko", 3.99, "001"),
                new Produkt("Chleb", 2.49, "002"),
                new Produkt("Masło", 6.99, "003")
        };


        Arrays.sort(produkty);
        System.out.println("Posortowane po cenie:");
        for (Produkt p : produkty) {
            System.out.println(p);
        }


        Arrays.sort(produkty, new Produkt.ProduktPoNazwieComparator());
        System.out.println("Posortowane po nazwie:");
        for (Produkt p : produkty) {
            System.out.println(p);
        }
    }
}
