import java.util.Comparator;

public class Produkt implements Comparable<Produkt> {
    private String nazwa;
    private double cena;
    private String kod;

    public Produkt(String nazwa, double cena, String kod) {
        this.nazwa = nazwa;
        this.cena = cena;
        this.kod = kod;
    }

    public String getNazwa() {
        return nazwa;
    }

    public double getCena() {
        return cena;
    }

    @Override
    public int compareTo(Produkt other) {
        return Double.compare(this.cena, other.cena); // Porównanie po cenie
    }

    @Override
    public String toString() {
        return "Produkt{" +
                "nazwa='" + nazwa + '\'' +
                ", cena=" + cena +
                ", kod='" + kod + '\'' +
                '}';
    }


    public static class ProduktPoNazwieComparator implements Comparator<Produkt> {
        @Override
        public int compare(Produkt p1, Produkt p2) {
            return p1.getNazwa().compareTo(p2.getNazwa()); // Porównanie po nazwie
        }
    }
}
