import java.util.Comparator;

public class Osoba implements Comparable<Osoba> {
    private String imie;
    private String nazwisko;
    private int rokUrodzenia;

    public Osoba(String imie, String nazwisko, int rokUrodzenia) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.rokUrodzenia = rokUrodzenia;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public int getRokUrodzenia() {
        return rokUrodzenia;
    }

    @Override
    public int compareTo(Osoba other) {
        int nazwiskoCompare = this.nazwisko.compareTo(other.nazwisko);
        if (nazwiskoCompare != 0) return nazwiskoCompare;

        int imieCompare = this.imie.compareTo(other.imie);
        if (imieCompare != 0) return imieCompare;

        return Integer.compare(this.rokUrodzenia, other.rokUrodzenia);
    }

    @Override
    public String toString() {
        return imie + " " + nazwisko + " (" + rokUrodzenia + ")";
    }


    public static class OsobaComparator implements Comparator<Osoba> {
        @Override
        public int compare(Osoba o1, Osoba o2) {
            int rokCompare = Integer.compare(o1.getRokUrodzenia(), o2.getRokUrodzenia());
            if (rokCompare != 0) return rokCompare;

            int nazwiskoCompare = o1.getNazwisko().compareTo(o2.getNazwisko());
            if (nazwiskoCompare != 0) return nazwiskoCompare;

            return o1.getImie().compareTo(o2.getImie());
        }
    }
}
