import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Osoba[] osoby = {
                new Osoba("Jan", "Kowalski", 1985),
                new Osoba("Anna", "Nowak", 1990),
                new Osoba("Jan", "Nowak", 1980)
        };


        Arrays.sort(osoby);
        System.out.println("Posortowane po nazwisku, imieniu, roku:");
        for (Osoba o : osoby) {
            System.out.println(o);
        }


        Arrays.sort(osoby, new Osoba.OsobaComparator());
        System.out.println("Posortowane po roku, nazwisku, imieniu:");
        for (Osoba o : osoby) {
            System.out.println(o);
        }
    }
}
